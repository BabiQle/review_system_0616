import { useState, useEffect } from 'react';
import { pb } from '@/db/pb';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Users, AlertTriangle, Check, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

// 固定负责人列（与 Excel 表头一致）
const COLUMN_NAMES = [
  '周毅', '邓海鹏', '刘奇', '余圳烨', '张克文', '何俊广',
  '杨通信', '郑鹏', '黄永楷', '李虎', '姚开朗', '黄旭'
];

interface UserStatus {
  id: string;
  user: string;
  expand?: { user: { display_name: string; role: string } };
  project: string;
  responsible_person: string;
}

export default function OccupancyMatrix() {
  const [statusList, setStatusList] = useState<UserStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingCell, setEditingCell] = useState<{ userId: string; column: string } | null>(null);
  const [editValue, setEditValue] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const result = await pb.collection('user_status').getList(1, 200, {
        expand: 'user',
        sort: 'user.display_name',
      });
      // 过滤掉超级管理员（role === 'admin'）
      const filtered = result.items.filter((item: any) => item.expand?.user?.role !== 'admin');
      setStatusList(filtered as UserStatus[]);
    } catch (err) {
      console.error(err);
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  // 构建员工列表，添加序号和分配状态（仅非管理员）
  const employees = statusList.map((item, idx) => ({
    id: item.user,
    name: item.expand?.user?.display_name || '未知',
    responsible: item.responsible_person || '',
    project: item.project || '',
    isAssigned: !!item.responsible_person,
    serial: idx + 1,
  }));

  const unassignedCount = employees.filter(emp => !emp.isAssigned).length;

  // 获取单元格显示的项目名称
  const getCellValue = (emp: typeof employees[0], column: string) => {
    return emp.responsible === column ? emp.project : '';
  };

  // 开始编辑
  const startEdit = (emp: typeof employees[0], column: string) => {
    setEditingCell({ userId: emp.id, column });
    setEditValue(getCellValue(emp, column));
  };

  // 取消编辑
  const cancelEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  // 保存编辑
  const saveEdit = async (emp: typeof employees[0], column: string) => {
    const newProject = editValue.trim();
    const newResponsible = newProject ? column : '';
    try {
      const record = statusList.find(s => s.user === emp.id);
      if (!record) {
        toast.error('记录不存在');
        return;
      }
      await pb.collection('user_status').update(record.id, {
        project: newProject,
        responsible_person: newResponsible,
      });
      toast.success('更新成功');
      await loadData();
    } catch (err) {
      toast.error('更新失败');
    } finally {
      setEditingCell(null);
      setEditValue('');
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-sm">
          <Users className="h-5 w-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">人员占用矩阵</h1>
          <p className="text-xs text-slate-500">按负责人查看员工项目占用情况（点击单元格可编辑）</p>
        </div>
      </div>

      {/* 未分配提醒 */}
      {unassignedCount > 0 && (
        <div className="bg-amber-100 border border-amber-300 rounded-lg p-3 flex items-center gap-2 text-amber-800 shadow-sm">
          <AlertTriangle className="h-4 w-4" />
          <span className="text-sm font-medium">有 {unassignedCount} 名员工尚未分配项目，请及时安排工作。</span>
        </div>
      )}

      <Card className="border border-slate-200 shadow-sm bg-white">
        <CardHeader className="border-b border-slate-100 bg-slate-50/50 py-4">
          <CardTitle className="text-base font-bold text-slate-900">占用矩阵</CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-auto" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          <table className="w-full border-collapse text-sm">
            <thead className="sticky top-0 z-10 bg-slate-100">
              <tr className="border-b border-slate-200">
                <th className="sticky left-0 z-20 bg-slate-100 px-4 py-2 text-left font-medium w-12">序号</th>
                <th className="sticky left-12 z-20 bg-slate-100 px-4 py-2 text-left font-medium min-w-[120px]">员工</th>
                {COLUMN_NAMES.map(name => (
                  <th key={name} className="px-4 py-2 text-left font-medium min-w-[100px] bg-slate-100">{name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map(emp => (
                <tr
                  key={emp.id}
                  className={`border-b border-slate-100 ${!emp.isAssigned ? 'bg-yellow-100 hover:bg-yellow-200' : 'hover:bg-slate-50'}`}
                >
                  <td className="sticky left-0 z-10 bg-white border-r border-slate-200 px-4 py-2 text-center text-slate-500 w-12">
                    {emp.serial}
                  </td>
                  <td className="sticky left-12 z-10 bg-white border-r border-slate-200 px-4 py-2 font-medium min-w-[120px]">
                    {emp.name}
                  </td>
                  {COLUMN_NAMES.map(col => {
                    const isEditing = editingCell?.userId === emp.id && editingCell?.column === col;
                    const cellValue = getCellValue(emp, col);
                    return (
                      <td
                        key={col}
                        className="px-4 py-2 cursor-pointer transition-colors"
                        onClick={() => startEdit(emp, col)}
                      >
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <Input
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              className="h-7 text-sm"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') saveEdit(emp, col);
                                if (e.key === 'Escape') cancelEdit();
                              }}
                            />
                            <button onClick={() => saveEdit(emp, col)} className="text-green-600 hover:text-green-700">
                              <Check className="h-4 w-4" />
                            </button>
                            <button onClick={cancelEdit} className="text-red-600 hover:text-red-700">
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ) : (
                          <span>{cellValue}</span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}