import { useState, useEffect, useRef } from 'react';
import { pb } from '@/db/pb';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Users, AlertTriangle, Check, X, Trash2, Copy } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

// 固定负责人列
const COLUMN_NAMES = [
  '周毅', '邓海鹏', '刘奇', '余圳烨', '张克文', '何俊广',
  '杨通信', '郑鹏', '黄永楷', '李虎', '姚开朗', '黄旭'
];

// localStorage 键名前缀
const HISTORY_KEY_PREFIX = 'project_history_';

// 获取某个负责人的历史记录
const getHistory = (column: string): string[] => {
  const key = HISTORY_KEY_PREFIX + column;
  const raw = localStorage.getItem(key);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

// 保存历史记录（去重、保持最近10条）
const addToHistory = (column: string, value: string) => {
  if (!value.trim()) return;
  const key = HISTORY_KEY_PREFIX + column;
  let history = getHistory(column);
  history = [value, ...history.filter(v => v !== value)];
  if (history.length > 10) history = history.slice(0, 10);
  localStorage.setItem(key, JSON.stringify(history));
};

// 清除所有历史
const clearAllHistory = () => {
  COLUMN_NAMES.forEach(col => {
    localStorage.removeItem(HISTORY_KEY_PREFIX + col);
  });
  toast.success('已清除所有项目历史记录');
};

interface UserStatus {
  id: string;
  user: string;
  expand?: { user: { display_name: string; role: string } };
  project: string;
  responsible_person: string;
}

export default function OccupancyMatrixFull() {
  const [statusList, setStatusList] = useState<UserStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingCell, setEditingCell] = useState<{ userId: string; column: string } | null>(null);
  const [editValue, setEditValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    document.title = '人员占用矩阵';
    loadData();
  }, []);

  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
    }
  }, [editingCell]);

  const loadData = async () => {
    try {
      const result = await pb.collection('user_status').getList(1, 200, {
        expand: 'user',
        sort: 'user.display_name',
      });
      const filtered = result.items.filter((item: any) => item.expand?.user?.role !== 'admin');
      setStatusList(filtered as UserStatus[]);
    } catch (err) {
      console.error(err);
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const employees = statusList.map((item, idx) => ({
    id: item.user,
    name: item.expand?.user?.display_name || '未知',
    responsible: item.responsible_person || '',
    project: item.project || '',
    isAssigned: !!item.responsible_person,
    serial: idx + 1,
  }));

  const unassignedCount = employees.filter(emp => !emp.isAssigned).length;

  const getCellValue = (emp: typeof employees[0], column: string) => {
    return emp.responsible === column ? emp.project : '';
  };

  const startEdit = (emp: typeof employees[0], column: string) => {
    setEditingCell({ userId: emp.id, column });
    setEditValue(getCellValue(emp, column));
  };

  const cancelEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  const saveEdit = async (emp: typeof employees[0], column: string, newValue: string) => {
    const newProject = newValue.trim();
    const newResponsible = newProject ? column : '';
    if (newProject) {
      addToHistory(column, newProject);
    }
    try {
      const record = statusList.find(s => s.user === emp.id);
      if (!record) throw new Error('记录不存在');
      await pb.collection('user_status').update(record.id, {
        project: newProject,
        responsible_person: newResponsible,
      });
      toast.success('更新成功');
      await loadData();
    } catch (err) {
      toast.error('更新失败');
    } finally {
      setEditingCell(null);
      setEditValue('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, emp: typeof employees[0], column: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveEdit(emp, column, editValue);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      cancelEdit();
    } else if (e.key === 'Delete' && !editValue) {
      saveEdit(emp, column, '');
    }
  };

  const copyToNext = async (emp: typeof employees[0], column: string) => {
    const currentValue = getCellValue(emp, column);
    if (!currentValue) {
      toast.info('当前单元格为空，无法复制');
      return;
    }
    const currentIndex = employees.findIndex(e => e.id === emp.id);
    const nextEmp = employees.slice(currentIndex + 1).find(e => !e.isAssigned && e.responsible !== column);
    if (!nextEmp) {
      toast.info('没有找到可填充的未分配员工');
      return;
    }
    try {
      const record = statusList.find(s => s.user === nextEmp.id);
      if (!record) throw new Error('记录不存在');
      await pb.collection('user_status').update(record.id, {
        project: currentValue,
        responsible_person: column,
      });
      toast.success(`已复制到 ${nextEmp.name}`);
      await loadData();
    } catch (err) {
      toast.error('复制失败');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Skeleton className="h-96 w-full max-w-6xl" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-full mx-auto">
        {/* 紧凑顶部栏 */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex gap-2">
            {unassignedCount > 0 && (
              <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1 shadow-sm">
                <AlertTriangle className="h-4 w-4" />
                未分配员工: {unassignedCount}
              </div>
            )}
          </div>
          <Button variant="outline" size="sm" onClick={clearAllHistory} className="gap-1 text-xs h-8">
            <Trash2 className="h-3 w-3" />
            清除所有历史
          </Button>
        </div>

        <Card className="border border-slate-200 shadow-lg bg-white">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 py-2 px-4">
            <CardTitle className="text-sm font-bold text-slate-900">占用矩阵（双击单元格编辑）</CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-auto" style={{ maxHeight: 'calc(100vh - 120px)' }}>
            <table className="min-w-[1200px] w-full border-collapse text-sm">
              <thead className="sticky top-0 z-10 bg-slate-100">
                <tr className="border-b border-slate-200">
                  <th className="sticky left-0 z-20 bg-slate-100 px-3 py-2 text-left font-medium w-12">序号</th>
                  <th className="sticky left-12 z-20 bg-slate-100 px-3 py-2 text-left font-medium min-w-[120px]">员工</th>
                  {COLUMN_NAMES.map(name => (
                    <th key={name} className="px-3 py-2 text-left font-medium min-w-[110px] bg-slate-100">{name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {employees.map(emp => (
                  <tr
                    key={emp.id}
                    className={`border-b border-slate-100 ${!emp.isAssigned ? 'bg-yellow-100 hover:bg-yellow-200' : 'hover:bg-slate-50'}`}
                  >
                    <td className="sticky left-0 z-10 bg-white border-r border-slate-200 px-3 py-2 text-center text-slate-500 w-12">
                      {emp.serial}
                    </td>
                    <td className="sticky left-12 z-10 bg-white border-r border-slate-200 px-3 py-2 font-medium min-w-[120px]">
                      {emp.name}
                    </td>
                    {COLUMN_NAMES.map(col => {
                      const isEditing = editingCell?.userId === emp.id && editingCell?.column === col;
                      const cellValue = getCellValue(emp, col);
                      const historyList = getHistory(col);
                      return (
                        <td
                          key={col}
                          className="px-3 py-2 cursor-pointer transition-colors group relative"
                          onDoubleClick={() => startEdit(emp, col)}
                        >
                          {isEditing ? (
                            <div className="flex items-center gap-1">
                              <Input
                                ref={inputRef}
                                list={`datalist-${col}`}
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                onKeyDown={(e) => handleKeyDown(e, emp, col)}
                                onBlur={() => saveEdit(emp, col, editValue)}
                                className="h-8 px-2 text-sm"
                                autoFocus
                              />
                              <datalist id={`datalist-${col}`}>
                                {historyList.map(h => <option key={h} value={h} />)}
                              </datalist>
                              <button onClick={() => saveEdit(emp, col, editValue)} className="text-green-600 hover:text-green-700">
                                <Check className="h-4 w-4" />
                              </button>
                              <button onClick={cancelEdit} className="text-red-600 hover:text-red-700">
                                <X className="h-4 w-4" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex justify-between items-center">
                              <span>{cellValue}</span>
                              {cellValue && (
                                <button
                                  onClick={(e) => { e.stopPropagation(); copyToNext(emp, col); }}
                                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                                  title="复制到下一个未分配员工"
                                >
                                  <Copy className="h-3.5 w-3.5 text-blue-500" />
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}